from PIL import Image, ImageDraw
import numpy as np
from abc import ABC, abstractmethod

s = "/home/vladimir/pict.tif"
image = Image.open(s)
x = np.asarray(image)
print(x)