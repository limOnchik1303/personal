from PIL import Image, ImageDraw
import numpy as np
from abc import ABC, abstractmethod
import ctypes


def draw_extrem(image, array_lines):
    length = len(array_lines)
    draw = ImageDraw.Draw(image, "RGB")
    for i in range(length):
        draw.line(array_lines[i], (0, 0, 0), 1)
    del draw
    image.save("/home/vladimir/test2.png", "PNG")

class InterferogramModel:
    """ Contains the data of the interferogram.
        Can:
        - store the image of the interferogram
        - store image as numpy matrix
        - get the whole numpy matrix
        - get rgb pixel
        - get any channel of the pixel (0-r, 1 - g and so on)
        - get green section
        - get width and height of image
    """
    __image = 0
    __NpImage = 0

    def set_image(self, s):
        self.__image = Image.open(s)
        self.__NpImage = np.asarray(self.__image)

    def get_image_npmatrix(self):
        return self.__NpImage

    def get_canal_pixel(self, y, x, c):
        return self.__NpImage[y, x, c]

    def get_rgb_pixel(self, y, x):
        return self.__NpImage[y, x]

    def get_green_section(self, x):
        return self.__NpImage[:, x, 1]

    def get_shape(self):
        return self.__NpImage.shape

    def get_height(self):
        return self.__NpImage.shape[0]

    def get_width(self):
        return self.__NpImage.shape[1]



class TracerVolosnikov:
    def __init__(self, num):
        self.__matrix = num             #NumPy matrix
        self.__length = num.shape[0]
        self.__width = num.shape[1]
        self.__lib = ctypes.CDLL('./call.so')

    def search_minimal_period(self, array):
        pfun = self.__lib.