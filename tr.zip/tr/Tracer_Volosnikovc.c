#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>

struct interval{
    int start;
    int finish;
};

int calculation_array_length(int* array) {}

int int_max(int* int_array, int length) {
    int res = 0;
    for (int i = 0; i < length; i++) {
        if (res < int_array[i])
            res = int_array[i];
    }
    return res;
}

double double_max(double* double_array, int length) {
    double res = 0;
    for (int i = 0; i < length; i++) {
        if (res < double_array[i])
            res = double_array[i];
    }
    return res;
}

int int_min(int* int_array, int length) {
    int res = int_max(int_array, length);
    for (int i = 0; i < length; i++) {
        if (res > int_array[i])
            res = int_array[i];
    }
    return res;
}

double double_min(double* double_array, int length) {
    double res = double_max(double_array, length);
    for (int i = 0; i < length; i++) {
        if (res > double_array[i])
            res = double_array[i];
    }
    return res;
}

int int_search_minimal_period(int* array, int length) {
    int maximum = int_max(array, length);
    int minimum = int_min(array, length);
    int y1 = (int)(minimum + (maximum - minimum) / 5);
    int y2 = (int)(maximum - (maximum - minimum) / 5);
    int amount_intersections, average_amount = 0, result;

    for (int y = y1; y < y2; y++){
        amount_intersections = 0;
        for (int i = 1; i < length; i++){
            if (((array[i - 1] <= y) && (y < array[i])) || ((array[i - 1] >= y) && (y > array[i]))) {
                amount_intersections++;
            }
        }
        average_amount = average_amount + amount_intersections;
    }
    average_amount = (int)(average_amount / (y2 - y1));
    result = (int)(length * 2 / average_amount);
    return result;
}

int double_search_minimal_period(double* array, int length) {
    double maximum = double_max(array, length);
    double minimum = double_min(array, length);
    double y1 = (minimum + (maximum - minimum) / 5);
    double y2 = (maximum - (maximum - minimum) / 5);
    int amount_intersections, average_amount = 0, result;

    for (double y = y1; y < y2; y = y + 1){
        amount_intersections = 0;
        for (int i = 1; i < length; i++){
            if (((array[i - 1] <= y) && (y < array[i])) || ((array[i - 1] >= y) && (y > array[i]))) {
                amount_intersections++;
            }
        }
        average_amount = average_amount + amount_intersections;
    }
    average_amount = (int)(average_amount / (y2 - y1));
    result = (int)(length * 2 / average_amount);
    return result;
}

struct interval calculation_interval(int x, int length, int* int_array, double* double_array, int flag, int parameter) {
    int amount_points;

    struct interval result;
    if ((parameter == 0) && (flag == 0))
        amount_points = int_search_minimal_period(int_array, length);
    else if ((parameter == 0) && (flag == 1))
        amount_points = double_search_minimal_period(double_array, length);
    else
        amount_points = parameter;
    if (x < amount_points) {
        result.start = 0;
        result.finish = x + amount_points;
    }
    else if (x >= length - amount_points) {
        result.start = x - amount_points;
        result.finish = length;
    }
    else {
        result.start = x - amount_points;
        result.finish = x + amount_points;
    }
    return result;
}

void array_averaging(int parameter, int length, int* array) {
    struct interval segment;
    int sum;
    int* intermediate_array = (int*)malloc(length * sizeof(int));

    for (int i = 0; i < length; i++) {
        segment = calculation_interval(i, length, array, NULL, 0, 0);
        sum = 0;
        for (int j = segment.start; j < segment.finish; j++) {
            sum = sum + array[j];
        }
        intermediate_array[i] = (int)(sum / (segment.finish - segment.start));
    }
    for (int i = 0; i < length; i++)
        array[i] = intermediate_array[i];
    free(intermediate_array);
}

void create_array_square_deviation(int* array, int input_length, double* result_array) {
    long sum1, sum2, sum3;
    float res;
    struct interval segment;
    *out_length = length

    for (int i = 0; i < length; i++) {
        segment = calculation_interval(i, length, array, NULL, 0, 0);
        sum1 = 0;
        sum2 = 0;
        sum3 = 0;
        for (int j = segment.start; j < segment.finish; j++) {
            sum1 = sum1 + pow((array[j] - array[i]), 2);
            sum2 = sum2 + (array[j] - array[i]) * pow((j - i), 2);
            sum3 = sum3 + pow((j - i), 4);
        }
        res = sum1 - (pow(sum2, 2)) / sum3;
        result_array[i] = res;
    }
}

void search_minima(double* array, int length, int* result_array, int* out_length) {
    struct interval segment;
    double* intermediate_array = (double*)malloc(length * sizeof(double));
    int j = 0, t, res, number = 0;

    for (int i = 0; i < length; i++) {
        segment = calculation_interval(i, length, NULL, array, 1, 0);
        intermediate_array[i] = double_min(array + sizeof(double) * segment.start, segment.finish - segment.start);
    }
    while (j < length - 1) {
        if ((j < length - 1) && (intermediate_array[j] == intermediate_array[j + 1])) {
            t = 0;
            while ((j < length - 1) && (intermediate_array[j] == intermediate_array[j + 1])) {
                t++;
                j++;
            }
            res = j - (int)(t / 2);
            result_array[number] = res;
            number++;
        }
        else
            j++;
    }
    *out_length = number;
}

void second_search_extrem(int* x_array, int length, int* y_array, int* result_array, int* out_length) {
    int j = 1, number = 0;

    while(j < length - 1) {
        if (!(((y_array[x_array[j - 1]] < y_array[x_array[j]]) && (y_array[x_array[j]] < y_array[x_array[j + 1]])) ||
              ((y_array[x_array[j - 1]] > y_array[x_array[j]]) && (y_array[x_array[j]] > y_array[x_array[j + 1]])))) {
            result_array[number] = x_array[j];
            number++;
        }
        j++;
    }
    *out_length = number;
}

void create_all_extrem(int averaging_parameter, int** in_array, int** out_array, int width, int height) {
    double* square_deviation_array = (double*)malloc(height * sizeof(double));
    int* first_array_minima = (int*)malloc(heigth * sizeof(int));
    int* second_array_minima = (int*)malloc(height * sizeof(int));
    int length1 = 0, length2 = 0;

    for (int i = 0; i < width; i++) {
        array_averaging(averaging_parameter, height, in_array[i]);
        create_array_square_deviation(in_array[i], height, square_deviation_array);
        search_minima(square_deviation_array, height, first_array_minima, &length1);
        second_search_extrem(first_array_minima, length1, in_array[i], second_array_minima, &length2);
        out_array[i][0] = length2;
        for (int j = 1; j <= length; j++) {
            out_array[i][j] = second_array_minima[j - 1];
        }
    }
}

void create_lines(int** in_array, int parameter,
                  int** out_array, int* amount_lines,
                  int width, int height)
{
    int** array_all_extrems = (int**)malloc(width * height * sizeof(int));
    create_all_extrem(parameter, in_array, array_all_extrems, width, height);
    int* array_lengthes_slices = (int*)malloc(width * sizeof(int));

    for (int i = 0; i < width; i++) {
        array_lengthes_slices[i] = array_all_extrems[i][0];
    }
    *amount_lines = int_min(array_lengthes_slices, width);
    for (int i = 0; i < *amount_lines; i++) {
        for (int j = 0; j < width; j++) {
            out_array[i][j] = array_all_extrems[j][i];
        }
    }
}














