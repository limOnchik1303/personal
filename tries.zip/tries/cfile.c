#include <stdio.h>
#include <stdlib.h>

void fun_numpy(int* array) {
    FILE *s;
    s = fopen("file.txt", "w");
    for (int i = 0; i < 4; i++) {
        fprintf(s, "%d, ", array[i]);
    }
    fclose(s);

}
