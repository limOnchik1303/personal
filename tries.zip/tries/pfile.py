import numpy as np
from PIL import Image, ImageDraw
import ctypes

lib = ctypes.CDLL('./cfile.so')


pfun = lib.fun_numpy
x = np.array([[1, 2], [3, 4]])
c_int_p = ctypes.POINTER(ctypes.c_int)
data_p = x.ctypes.data_as(c_int_p)

pfun.argtypes = (data_p, )
res = pfun(x)
